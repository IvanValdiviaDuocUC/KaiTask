
  # KaiTasks Prototipo de App

  This is a code bundle for KaiTasks Prototipo de App. The original project is available at https://www.figma.com/design/1rvRUfHjJb69L6SK758YIm/KaiTasks-Prototipo-de-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  