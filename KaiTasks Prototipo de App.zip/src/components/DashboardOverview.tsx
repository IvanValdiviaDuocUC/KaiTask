import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  TrendingUp,
  Plus,
  Eye,
  Calendar,
  Users
} from 'lucide-react';

interface DashboardOverviewProps {
  userRole: 'manager' | 'supervisor' | 'collaborator';
  userName: string;
}

const recentTasks = [
  {
    id: '1',
    title: 'Revisar presupuesto mensual',
    status: 'in_progress',
    assignee: 'Ana García',
    dueDate: '2024-03-25',
    priority: 'high'
  },
  {
    id: '2',
    title: 'Actualizar documentación técnica',
    status: 'waiting_validation',
    assignee: 'Miguel Santos',
    dueDate: '2024-03-28',
    priority: 'medium'
  },
  {
    id: '3',
    title: 'Preparar presentación Q1',
    status: 'pending',
    assignee: 'Sofia Ruiz',
    dueDate: '2024-03-22',
    priority: 'high'
  }
];

const upcomingDeadlines = [
  { task: 'Preparar presentación Q1', dueDate: '2024-03-22', assignee: 'Sofia Ruiz' },
  { task: 'Revisar presupuesto mensual', dueDate: '2024-03-25', assignee: 'Ana García' },
  { task: 'Auditoría de seguridad', dueDate: '2024-03-26', assignee: 'Elena Vega' }
];

const teamUpdates = [
  { name: 'Juan Pérez', action: 'completó', task: 'Capacitación en nuevas herramientas', time: '2 horas' },
  { name: 'Ana García', action: 'comentó en', task: 'Revisar presupuesto mensual', time: '4 horas' },
  { name: 'Miguel Santos', action: 'envió para validación', task: 'Actualizar documentación', time: '6 horas' }
];

export function DashboardOverview({ userRole, userName }: DashboardOverviewProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'in_progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'pending': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'waiting_validation': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'overdue': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed': return 'Completada';
      case 'in_progress': return 'En Progreso';
      case 'pending': return 'Pendiente';
      case 'waiting_validation': return 'En Validación';
      case 'overdue': return 'Vencida';
      default: return status;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'low': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case 'high': return 'Alta';
      case 'medium': return 'Media';
      case 'low': return 'Baja';
      default: return priority;
    }
  };

  // Mock data específica por rol
  const getMyStats = () => {
    if (userRole === 'collaborator') {
      return {
        assigned: 8,
        completed: 5,
        pending: 2,
        overdue: 1
      };
    } else if (userRole === 'supervisor') {
      return {
        team: 12,
        completed: 28,
        pending: 15,
        validation: 6
      };
    } else {
      return {
        total: 156,
        completed: 98,
        pending: 35,
        overdue: 11
      };
    }
  };

  const stats = getMyStats();

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            Bienvenido, {userName}
          </h1>
          <p className="text-slate-600 mt-1">
            {userRole === 'collaborator' && 'Aquí tienes un resumen de tus tareas'}
            {userRole === 'supervisor' && 'Resumen del rendimiento de tu equipo'}
            {userRole === 'manager' && 'Vista general del estado organizacional'}
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          {(userRole === 'supervisor' || userRole === 'manager') && (
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Tarea
            </Button>
          )}
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Calendario
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {userRole === 'collaborator' && (
          <>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tareas Asignadas</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.assigned}</div>
                <Progress value={(stats.completed / stats.assigned) * 100} className="mt-2" />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completadas</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-600">{stats.completed}</div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((stats.completed / stats.assigned) * 100)}% de progreso
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
                <Clock className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">{stats.pending}</div>
                <p className="text-xs text-muted-foreground">Por iniciar</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vencidas</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{stats.overdue}</div>
                <p className="text-xs text-muted-foreground">Requieren atención</p>
              </CardContent>
            </Card>
          </>
        )}

        {userRole === 'supervisor' && (
          <>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Miembros del Equipo</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.team}</div>
                <p className="text-xs text-muted-foreground">Colaboradores activos</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tareas Completadas</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-600">{stats.completed}</div>
                <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                  <TrendingUp className="h-3 w-3 text-emerald-500" />
                  <span className="text-emerald-500">+15%</span>
                  <span>vs semana anterior</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
                <Clock className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">{stats.pending}</div>
                <p className="text-xs text-muted-foreground">En progreso</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Por Validar</CardTitle>
                <Eye className="h-4 w-4 text-blue-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">{stats.validation}</div>
                <p className="text-xs text-muted-foreground">Esperan aprobación</p>
              </CardContent>
            </Card>
          </>
        )}

        {userRole === 'manager' && (
          <>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Tareas</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.total}</div>
                <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                  <TrendingUp className="h-3 w-3 text-emerald-500" />
                  <span className="text-emerald-500">+12%</span>
                  <span>vs mes anterior</span>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Completadas</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-emerald-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-emerald-600">{stats.completed}</div>
                <Progress value={(stats.completed / stats.total) * 100} className="mt-2" />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pendientes</CardTitle>
                <Clock className="h-4 w-4 text-amber-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-amber-600">{stats.pending}</div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((stats.pending / stats.total) * 100)}% del total
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vencidas</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-red-600">{stats.overdue}</div>
                <p className="text-xs text-muted-foreground">Requieren atención inmediata</p>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Tasks */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>
              {userRole === 'collaborator' ? 'Mis Tareas Recientes' : 'Tareas Recientes'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentTasks.map((task) => (
              <div key={task.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium text-slate-900 truncate">{task.title}</h4>
                  <div className="flex items-center space-x-2 mt-1">
                    <Avatar className="h-5 w-5">
                      <AvatarFallback className="text-xs">
                        {task.assignee.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm text-slate-600">{task.assignee}</span>
                    <span className="text-sm text-slate-500">•</span>
                    <span className="text-sm text-slate-500">
                      {new Date(task.dueDate).toLocaleDateString('es-ES')}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2 ml-4">
                  <Badge variant="outline" className={getPriorityColor(task.priority)}>
                    {getPriorityLabel(task.priority)}
                  </Badge>
                  <Badge variant="outline" className={getStatusColor(task.status)}>
                    {getStatusLabel(task.status)}
                  </Badge>
                </div>
              </div>
            ))}
            
            <Button variant="outline" className="w-full">
              Ver todas las tareas
            </Button>
          </CardContent>
        </Card>

        {/* Right Column */}
        <div className="space-y-6">
          {/* Upcoming Deadlines */}
          <Card>
            <CardHeader>
              <CardTitle>Próximos Vencimientos</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {upcomingDeadlines.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-900 truncate">{item.task}</p>
                    <p className="text-xs text-slate-600">{item.assignee}</p>
                  </div>
                  <div className="text-right ml-2">
                    <p className="text-sm font-medium text-slate-900">
                      {new Date(item.dueDate).toLocaleDateString('es-ES', { month: 'short', day: 'numeric' })}
                    </p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Team Activity */}
          {userRole !== 'collaborator' && (
            <Card>
              <CardHeader>
                <CardTitle>Actividad del Equipo</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {teamUpdates.map((update, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <Avatar className="h-6 w-6 mt-0.5">
                      <AvatarFallback className="text-xs">
                        {update.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm">
                        <span className="font-medium">{update.name}</span>
                        <span className="text-slate-600"> {update.action} </span>
                        <span className="font-medium">{update.task}</span>
                      </p>
                      <p className="text-xs text-slate-500">hace {update.time}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}