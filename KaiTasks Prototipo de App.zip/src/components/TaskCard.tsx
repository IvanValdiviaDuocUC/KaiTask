import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { 
  Clock, 
  User, 
  Building2, 
  AlertTriangle,
  CheckCircle2,
  Circle,
  Paperclip,
  Eye
} from 'lucide-react';

export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'in_progress' | 'completed' | 'overdue' | 'waiting_validation';
  priority: 'low' | 'medium' | 'high';
  assignee: string;
  department: string;
  dueDate: string;
  createdBy: string;
  hasAttachment?: boolean;
}

interface TaskCardProps {
  task: Task;
  userRole: 'manager' | 'supervisor' | 'collaborator';
  onStatusChange?: (taskId: string, newStatus: Task['status']) => void;
  onValidate?: (taskId: string, action: 'approve' | 'reject') => void;
  onViewDetails?: (taskId: string) => void;
}

export function TaskCard({ task, userRole, onStatusChange, onValidate, onViewDetails }: TaskCardProps) {
  const getStatusColor = (status: Task['status']) => {
    switch (status) {
      case 'pending': return 'bg-slate-100 text-slate-700 border-slate-200';
      case 'in_progress': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'completed': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      case 'overdue': return 'bg-red-100 text-red-700 border-red-200';
      case 'waiting_validation': return 'bg-amber-100 text-amber-700 border-amber-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getStatusLabel = (status: Task['status']) => {
    switch (status) {
      case 'pending': return 'Pendiente';
      case 'in_progress': return 'En Progreso';
      case 'completed': return 'Completada';
      case 'overdue': return 'Vencida';
      case 'waiting_validation': return 'En Validación';
      default: return status;
    }
  };

  const getPriorityColor = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'low': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const getPriorityLabel = (priority: Task['priority']) => {
    switch (priority) {
      case 'high': return 'Alta';
      case 'medium': return 'Media';
      case 'low': return 'Baja';
      default: return priority;
    }
  };

  const getStatusIcon = (status: Task['status']) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="h-4 w-4" />;
      case 'in_progress': return <Clock className="h-4 w-4" />;
      case 'overdue': return <AlertTriangle className="h-4 w-4" />;
      default: return <Circle className="h-4 w-4" />;
    }
  };

  const isOverdue = new Date(task.dueDate) < new Date() && task.status !== 'completed';
  const canChangeStatus = userRole === 'collaborator' || userRole === 'supervisor';
  const canValidate = userRole === 'supervisor' && task.status === 'waiting_validation';

  return (
    <Card className={`transition-shadow hover:shadow-md ${isOverdue ? 'border-red-200' : ''}`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <h3 className="font-medium text-slate-900 truncate">{task.title}</h3>
            <p className="text-sm text-slate-600 mt-1 line-clamp-2">{task.description}</p>
          </div>
          <div className="flex items-center space-x-2 ml-4">
            <Badge variant="outline" className={getPriorityColor(task.priority)}>
              {getPriorityLabel(task.priority)}
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0 space-y-4">
        {/* Status and Department */}
        <div className="flex items-center justify-between">
          <Badge variant="outline" className={`${getStatusColor(task.status)} flex items-center space-x-1`}>
            {getStatusIcon(task.status)}
            <span>{getStatusLabel(task.status)}</span>
          </Badge>
          
          <div className="flex items-center space-x-1 text-sm text-slate-600">
            <Building2 className="h-4 w-4" />
            <span>{task.department}</span>
          </div>
        </div>

        {/* Assignee and Due Date */}
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-2">
            <Avatar className="h-6 w-6">
              <AvatarFallback className="text-xs">
                {task.assignee.split(' ').map(n => n[0]).join('').toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <span className="text-slate-700">{task.assignee}</span>
          </div>
          
          <div className="flex items-center space-x-1 text-slate-600">
            <Clock className="h-4 w-4" />
            <span className={isOverdue ? 'text-red-600 font-medium' : ''}>
              {new Date(task.dueDate).toLocaleDateString('es-ES')}
            </span>
          </div>
        </div>

        {/* Attachment indicator */}
        {task.hasAttachment && (
          <div className="flex items-center space-x-1 text-sm text-slate-600">
            <Paperclip className="h-4 w-4" />
            <span>Archivo adjunto</span>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onViewDetails?.(task.id)}
            className="text-slate-600 hover:text-slate-900"
          >
            <Eye className="h-4 w-4 mr-1" />
            Ver detalles
          </Button>

          <div className="flex items-center space-x-2">
            {canValidate && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onValidate?.(task.id, 'reject')}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  Rechazar
                </Button>
                <Button
                  size="sm"
                  onClick={() => onValidate?.(task.id, 'approve')}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  Aprobar
                </Button>
              </>
            )}

            {canChangeStatus && task.status !== 'completed' && task.status !== 'waiting_validation' && (
              <Button
                size="sm"
                variant="outline"
                onClick={() => {
                  const nextStatus = task.status === 'pending' ? 'in_progress' : 'waiting_validation';
                  onStatusChange?.(task.id, nextStatus);
                }}
                className="border-blue-200 text-blue-600 hover:bg-blue-50"
              >
                {task.status === 'pending' ? 'Iniciar' : 'Finalizar'}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}