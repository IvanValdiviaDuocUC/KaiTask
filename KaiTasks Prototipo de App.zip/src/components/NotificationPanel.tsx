import { useState } from 'react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Separator } from './ui/separator';
import { 
  Bell, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  UserPlus, 
  MessageSquare,
  Archive,
  Settings,
  MoreVertical
} from 'lucide-react';

interface Notification {
  id: string;
  type: 'assignment' | 'deadline' | 'completion' | 'validation' | 'comment';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high';
  relatedTask?: string;
  from?: string;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'deadline',
    title: 'Tarea próxima a vencer',
    message: 'La tarea "Revisar presupuesto mensual" vence en 2 días',
    timestamp: '2024-03-23T10:30:00Z',
    isRead: false,
    priority: 'high',
    relatedTask: 'Revisar presupuesto mensual'
  },
  {
    id: '2',
    type: 'assignment',
    title: 'Nueva tarea asignada',
    message: 'Te han asignado la tarea "Preparar informe de ventas"',
    timestamp: '2024-03-23T09:15:00Z',
    isRead: false,
    priority: 'medium',
    relatedTask: 'Preparar informe de ventas',
    from: 'Carlos López'
  },
  {
    id: '3',
    type: 'validation',
    title: 'Tarea pendiente de validación',
    message: 'Miguel Santos ha completado "Actualizar documentación técnica"',
    timestamp: '2024-03-23T08:45:00Z',
    isRead: true,
    priority: 'medium',
    relatedTask: 'Actualizar documentación técnica',
    from: 'Miguel Santos'
  },
  {
    id: '4',
    type: 'completion',
    title: 'Tarea completada',
    message: 'Juan Pérez ha finalizado "Capacitación en nuevas herramientas"',
    timestamp: '2024-03-22T16:20:00Z',
    isRead: true,
    priority: 'low',
    relatedTask: 'Capacitación en nuevas herramientas',
    from: 'Juan Pérez'
  },
  {
    id: '5',
    type: 'comment',
    title: 'Nuevo comentario',
    message: 'Ana García comentó en "Revisar presupuesto mensual"',
    timestamp: '2024-03-22T14:10:00Z',
    isRead: true,
    priority: 'low',
    relatedTask: 'Revisar presupuesto mensual',
    from: 'Ana García'
  }
];

export function NotificationPanel() {
  const [notifications, setNotifications] = useState(mockNotifications);
  const [filter, setFilter] = useState<'all' | 'unread' | 'high'>('all');

  const getNotificationIcon = (type: Notification['type']) => {
    switch (type) {
      case 'assignment': return <UserPlus className="h-5 w-5 text-blue-600" />;
      case 'deadline': return <Clock className="h-5 w-5 text-amber-600" />;
      case 'completion': return <CheckCircle2 className="h-5 w-5 text-emerald-600" />;
      case 'validation': return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case 'comment': return <MessageSquare className="h-5 w-5 text-purple-600" />;
      default: return <Bell className="h-5 w-5 text-slate-600" />;
    }
  };

  const getPriorityColor = (priority: Notification['priority']) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-700 border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'low': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const notificationTime = new Date(timestamp);
    const diffInHours = Math.floor((now.getTime() - notificationTime.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Hace menos de 1 hora';
    if (diffInHours < 24) return `Hace ${diffInHours} hora${diffInHours > 1 ? 's' : ''}`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `Hace ${diffInDays} día${diffInDays > 1 ? 's' : ''}`;
    
    return notificationTime.toLocaleDateString('es-ES');
  };

  const filteredNotifications = notifications.filter(notification => {
    switch (filter) {
      case 'unread': return !notification.isRead;
      case 'high': return notification.priority === 'high';
      default: return true;
    }
  });

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === notificationId ? { ...notif, isRead: true } : notif
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, isRead: true }))
    );
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <Bell className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold text-slate-900">Notificaciones</h1>
            <p className="text-slate-600">
              {unreadCount > 0 ? `${unreadCount} notificación${unreadCount > 1 ? 'es' : ''} sin leer` : 'Todo al día'}
            </p>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          {unreadCount > 0 && (
            <Button variant="outline" onClick={markAllAsRead}>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Marcar todo como leído
            </Button>
          )}
          <Button variant="outline">
            <Settings className="h-4 w-4 mr-2" />
            Configuración
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center space-x-2">
        <Button
          variant={filter === 'all' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('all')}
        >
          Todas ({notifications.length})
        </Button>
        <Button
          variant={filter === 'unread' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('unread')}
        >
          No leídas ({unreadCount})
        </Button>
        <Button
          variant={filter === 'high' ? 'default' : 'outline'}
          size="sm"
          onClick={() => setFilter('high')}
        >
          Prioridad alta ({notifications.filter(n => n.priority === 'high').length})
        </Button>
      </div>

      {/* Notifications List */}
      <div className="space-y-4">
        {filteredNotifications.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Bell className="h-12 w-12 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-slate-900 mb-2">No hay notificaciones</h3>
              <p className="text-slate-600">
                {filter === 'unread' 
                  ? 'No tienes notificaciones sin leer'
                  : filter === 'high'
                  ? 'No hay notificaciones de alta prioridad'
                  : 'No tienes notificaciones en este momento'
                }
              </p>
            </CardContent>
          </Card>
        ) : (
          filteredNotifications.map((notification, index) => (
            <Card 
              key={notification.id} 
              className={`transition-all hover:shadow-md cursor-pointer ${
                !notification.isRead ? 'bg-blue-50 border-blue-200' : ''
              }`}
              onClick={() => markAsRead(notification.id)}
            >
              <CardContent className="p-4">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    {getNotificationIcon(notification.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className={`font-medium ${!notification.isRead ? 'text-slate-900' : 'text-slate-700'}`}>
                            {notification.title}
                          </h3>
                          {!notification.isRead && (
                            <div className="w-2 h-2 bg-blue-600 rounded-full" />
                          )}
                        </div>
                        
                        <p className="text-sm text-slate-600 mb-2">
                          {notification.message}
                        </p>
                        
                        <div className="flex items-center space-x-4 text-xs text-slate-500">
                          <span>{formatTimeAgo(notification.timestamp)}</span>
                          {notification.from && (
                            <>
                              <span>•</span>
                              <div className="flex items-center space-x-1">
                                <Avatar className="h-4 w-4">
                                  <AvatarFallback className="text-xs">
                                    {notification.from.split(' ').map(n => n[0]).join('').toUpperCase()}
                                  </AvatarFallback>
                                </Avatar>
                                <span>{notification.from}</span>
                              </div>
                            </>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2 ml-4">
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getPriorityColor(notification.priority)}`}
                        >
                          {notification.priority === 'high' ? 'Alta' : 
                           notification.priority === 'medium' ? 'Media' : 'Baja'}
                        </Badge>
                        
                        <Button variant="ghost" size="sm">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    
                    {notification.relatedTask && (
                      <div className="mt-3 pt-3 border-t border-slate-100">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-600">
                            Tarea relacionada: <span className="font-medium">{notification.relatedTask}</span>
                          </span>
                          <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700">
                            Ver tarea
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
              
              {index < filteredNotifications.length - 1 && (
                <Separator className="mx-4" />
              )}
            </Card>
          ))
        )}
      </div>
    </div>
  );
}