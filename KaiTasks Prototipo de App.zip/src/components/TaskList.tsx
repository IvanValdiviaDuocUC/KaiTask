import { useState, useMemo } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { TaskCard, Task } from './TaskCard';
import { 
  Search, 
  Filter, 
  Plus, 
  Download,
  SortAsc
} from 'lucide-react';

interface TaskListProps {
  userRole: 'manager' | 'supervisor' | 'collaborator';
  userName: string;
}

// Mock data
const mockTasks: Task[] = [
  {
    id: '1',
    title: 'Revisar presupuesto mensual',
    description: 'Analizar gastos del departamento de marketing y crear reporte',
    status: 'in_progress',
    priority: 'high',
    assignee: 'Ana García',
    department: 'Marketing',
    dueDate: '2024-03-25',
    createdBy: 'Carlos López',
    hasAttachment: true
  },
  {
    id: '2',
    title: 'Actualizar documentación técnica',
    description: 'Documentar nuevos procedimientos de desarrollo',
    status: 'waiting_validation',
    priority: 'medium',
    assignee: 'Miguel Santos',
    department: 'Desarrollo',
    dueDate: '2024-03-28',
    createdBy: 'Laura Mendez'
  },
  {
    id: '3',
    title: 'Preparar presentación Q1',
    description: 'Crear slides para la presentación de resultados del primer trimestre',
    status: 'pending',
    priority: 'high',
    assignee: 'Sofia Ruiz',
    department: 'Ventas',
    dueDate: '2024-03-22',
    createdBy: 'Roberto Kim'
  },
  {
    id: '4',
    title: 'Capacitación en nuevas herramientas',
    description: 'Organizar sesión de entrenamiento para el equipo',
    status: 'completed',
    priority: 'medium',
    assignee: 'Juan Pérez',
    department: 'RRHH',
    dueDate: '2024-03-20',
    createdBy: 'María Torres'
  },
  {
    id: '5',
    title: 'Auditoría de seguridad',
    description: 'Revisar protocolos de seguridad informática',
    status: 'overdue',
    priority: 'high',
    assignee: 'Elena Vega',
    department: 'IT',
    dueDate: '2024-03-18',
    createdBy: 'David Chen'
  }
];

export function TaskList({ userRole, userName }: TaskListProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [tasks, setTasks] = useState(mockTasks);

  const departments = useMemo(() => {
    const deps = Array.from(new Set(tasks.map(task => task.department)));
    return deps.sort();
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      const matchesSearch = task.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          task.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          task.assignee.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
      const matchesDepartment = departmentFilter === 'all' || task.department === departmentFilter;
      const matchesPriority = priorityFilter === 'all' || task.priority === priorityFilter;

      // Para colaboradores, solo mostrar sus tareas asignadas
      const isAssignedToUser = userRole !== 'collaborator' || task.assignee === userName;

      return matchesSearch && matchesStatus && matchesDepartment && matchesPriority && isAssignedToUser;
    });
  }, [tasks, searchTerm, statusFilter, departmentFilter, priorityFilter, userRole, userName]);

  const taskStats = useMemo(() => {
    const stats = {
      total: filteredTasks.length,
      pending: filteredTasks.filter(t => t.status === 'pending').length,
      inProgress: filteredTasks.filter(t => t.status === 'in_progress').length,
      completed: filteredTasks.filter(t => t.status === 'completed').length,
      overdue: filteredTasks.filter(t => t.status === 'overdue').length,
      waitingValidation: filteredTasks.filter(t => t.status === 'waiting_validation').length
    };
    return stats;
  }, [filteredTasks]);

  const handleStatusChange = (taskId: string, newStatus: Task['status']) => {
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  const handleValidation = (taskId: string, action: 'approve' | 'reject') => {
    const newStatus = action === 'approve' ? 'completed' : 'pending';
    setTasks(prev => prev.map(task => 
      task.id === taskId ? { ...task, status: newStatus } : task
    ));
  };

  const clearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setDepartmentFilter('all');
    setPriorityFilter('all');
  };

  const activeFiltersCount = [statusFilter, departmentFilter, priorityFilter].filter(f => f !== 'all').length;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">
            {userRole === 'collaborator' ? 'Mis Tareas' : 'Gestión de Tareas'}
          </h1>
          <p className="text-slate-600 mt-1">
            {userRole === 'collaborator' 
              ? 'Visualiza y gestiona tus tareas asignadas'
              : 'Administra y supervisa las tareas del equipo'
            }
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          {(userRole === 'supervisor' || userRole === 'manager') && (
            <Button className="bg-blue-600 hover:bg-blue-700">
              <Plus className="h-4 w-4 mr-2" />
              Nueva Tarea
            </Button>
          )}
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-2xl font-semibold text-slate-900">{taskStats.total}</div>
          <div className="text-sm text-slate-600">Total</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-2xl font-semibold text-amber-600">{taskStats.pending}</div>
          <div className="text-sm text-slate-600">Pendientes</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-2xl font-semibold text-blue-600">{taskStats.inProgress}</div>
          <div className="text-sm text-slate-600">En Progreso</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-2xl font-semibold text-emerald-600">{taskStats.completed}</div>
          <div className="text-sm text-slate-600">Completadas</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-2xl font-semibold text-red-600">{taskStats.overdue}</div>
          <div className="text-sm text-slate-600">Vencidas</div>
        </div>
        <div className="bg-white p-4 rounded-lg border border-slate-200">
          <div className="text-2xl font-semibold text-orange-600">{taskStats.waitingValidation}</div>
          <div className="text-sm text-slate-600">Validación</div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg border border-slate-200 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-slate-600" />
            <span className="font-medium text-slate-900">Filtros</span>
            {activeFiltersCount > 0 && (
              <Badge variant="secondary" className="text-xs">
                {activeFiltersCount} activo{activeFiltersCount > 1 ? 's' : ''}
              </Badge>
            )}
          </div>
          {activeFiltersCount > 0 && (
            <Button variant="ghost" size="sm" onClick={clearFilters}>
              Limpiar filtros
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Buscar tareas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Estado" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los estados</SelectItem>
              <SelectItem value="pending">Pendiente</SelectItem>
              <SelectItem value="in_progress">En Progreso</SelectItem>
              <SelectItem value="completed">Completada</SelectItem>
              <SelectItem value="overdue">Vencida</SelectItem>
              <SelectItem value="waiting_validation">En Validación</SelectItem>
            </SelectContent>
          </Select>

          <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Departamento" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos los departamentos</SelectItem>
              {departments.map(dept => (
                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={priorityFilter} onValueChange={setPriorityFilter}>
            <SelectTrigger>
              <SelectValue placeholder="Prioridad" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas las prioridades</SelectItem>
              <SelectItem value="high">Alta</SelectItem>
              <SelectItem value="medium">Media</SelectItem>
              <SelectItem value="low">Baja</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Task Grid */}
      <div className="space-y-4">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-slate-400 mb-4">
              <Search className="h-12 w-12 mx-auto" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">No se encontraron tareas</h3>
            <p className="text-slate-600">
              {searchTerm || activeFiltersCount > 0 
                ? 'Intenta ajustar los filtros de búsqueda'
                : 'No hay tareas disponibles en este momento'
              }
            </p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                userRole={userRole}
                onStatusChange={handleStatusChange}
                onValidate={handleValidation}
                onViewDetails={(taskId) => console.log('Ver detalles de:', taskId)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}