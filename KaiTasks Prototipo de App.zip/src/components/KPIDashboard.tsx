import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  CheckCircle2, 
  Clock, 
  AlertTriangle,
  BarChart3,
  Download,
  Filter,
  Calendar
} from 'lucide-react';

const departmentData = [
  { name: 'Marketing', completed: 24, pending: 8, overdue: 2 },
  { name: 'Desarrollo', completed: 31, pending: 12, overdue: 1 },
  { name: 'Ventas', completed: 18, pending: 15, overdue: 4 },
  { name: 'RRHH', completed: 12, pending: 6, overdue: 1 },
  { name: 'IT', completed: 28, pending: 9, overdue: 3 }
];

const completionTrend = [
  { month: 'Ene', completed: 65, target: 70 },
  { month: 'Feb', completed: 72, target: 75 },
  { month: 'Mar', completed: 78, target: 80 },
  { month: 'Abr', completed: 85, target: 85 },
  { month: 'May', completed: 82, target: 90 },
  { month: 'Jun', completed: 88, target: 90 }
];

const priorityDistribution = [
  { name: 'Alta', value: 15, color: '#ef4444' },
  { name: 'Media', value: 45, color: '#f59e0b' },
  { name: 'Baja', value: 28, color: '#10b981' }
];

const teamPerformance = [
  { name: 'Ana García', completed: 12, assigned: 15, efficiency: 80 },
  { name: 'Miguel Santos', completed: 18, assigned: 20, efficiency: 90 },
  { name: 'Sofia Ruiz', completed: 14, assigned: 18, efficiency: 78 },
  { name: 'Juan Pérez', completed: 16, assigned: 16, efficiency: 100 },
  { name: 'Elena Vega', completed: 11, assigned: 17, efficiency: 65 }
];

export function KPIDashboard() {
  const totalTasks = 156;
  const completedTasks = 98;
  const pendingTasks = 35;
  const overdueTasks = 11;
  const validationTasks = 12;

  const completionRate = Math.round((completedTasks / totalTasks) * 100);
  const onTimeRate = Math.round(((completedTasks - 8) / completedTasks) * 100); // Asumiendo 8 completadas tarde

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">Dashboard Ejecutivo</h1>
          <p className="text-slate-600 mt-1">
            Resumen de rendimiento y métricas clave del equipo
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filtros
          </Button>
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            Período
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tareas Totales</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTasks}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3 text-emerald-500" />
              <span className="text-emerald-500">+12%</span>
              <span>vs mes anterior</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completadas</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-emerald-600">{completedTasks}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <TrendingUp className="h-3 w-3 text-emerald-500" />
              <span className="text-emerald-500">+8%</span>
              <span>vs mes anterior</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasa de Cumplimiento</CardTitle>
            <Users className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{completionRate}%</div>
            <Progress value={completionRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tareas Vencidas</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{overdueTasks}</div>
            <div className="flex items-center space-x-1 text-xs text-muted-foreground">
              <TrendingDown className="h-3 w-3 text-red-500" />
              <span className="text-red-500">-15%</span>
              <span>vs mes anterior</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Rendimiento por Departamento</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={departmentData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="completed" fill="#10b981" name="Completadas" />
                <Bar dataKey="pending" fill="#f59e0b" name="Pendientes" />
                <Bar dataKey="overdue" fill="#ef4444" name="Vencidas" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Priority Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Distribución por Prioridad</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie
                    data={priorityDistribution}
                    cx="50%"
                    cy="50%"
                    innerRadius={40}
                    outerRadius={80}
                    dataKey="value"
                  >
                    {priorityDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              
              <div className="space-y-3">
                {priorityDistribution.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-sm font-medium">{item.name}</span>
                    </div>
                    <Badge variant="outline">{item.value}</Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Completion Trend */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Tendencia de Completitud</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={completionTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="completed" 
                  stroke="#10b981" 
                  strokeWidth={3}
                  name="Completadas"
                />
                <Line 
                  type="monotone" 
                  dataKey="target" 
                  stroke="#6b7280" 
                  strokeDasharray="5 5"
                  name="Objetivo"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Team Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Top Colaboradores</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {teamPerformance.map((member, index) => (
              <div key={member.name} className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{member.name}</span>
                  <Badge 
                    variant="outline" 
                    className={
                      member.efficiency >= 90 ? 'text-emerald-600 border-emerald-200' :
                      member.efficiency >= 80 ? 'text-blue-600 border-blue-200' :
                      'text-amber-600 border-amber-200'
                    }
                  >
                    {member.efficiency}%
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{member.completed}/{member.assigned} tareas</span>
                </div>
                <Progress value={member.efficiency} className="h-2" />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Eficiencia del Equipo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-600 mb-2">{onTimeRate}%</div>
            <p className="text-sm text-muted-foreground">
              Tareas completadas a tiempo
            </p>
            <Progress value={onTimeRate} className="mt-3" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Carga de Trabajo</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Pendientes</span>
                <span className="font-medium">{pendingTasks}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">En validación</span>
                <span className="font-medium">{validationTasks}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Vencidas</span>
                <span className="font-medium text-red-600">{overdueTasks}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Alertas</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <div className="flex items-center space-x-2 text-sm">
              <AlertTriangle className="h-4 w-4 text-red-500" />
              <span>{overdueTasks} tareas vencidas</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <Clock className="h-4 w-4 text-amber-500" />
              <span>5 tareas vencen hoy</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <Users className="h-4 w-4 text-blue-500" />
              <span>{validationTasks} esperan validación</span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}