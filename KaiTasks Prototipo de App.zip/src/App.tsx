import { useState } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { MainLayout } from './components/MainLayout';
import { DashboardOverview } from './components/DashboardOverview';
import { TaskList } from './components/TaskList';
import { NotificationPanel } from './components/NotificationPanel';
import { KPIDashboard } from './components/KPIDashboard';

interface User {
  id: string;
  name: string;
  role: 'manager' | 'supervisor' | 'collaborator';
}

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState('dashboard');

  const handleLogin = (userData: User) => {
    setUser(userData);
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView('dashboard');
  };

  const renderCurrentView = () => {
    if (!user) return null;

    switch (currentView) {
      case 'dashboard':
        return <DashboardOverview userRole={user.role} userName={user.name} />;
      case 'tasks':
        return <TaskList userRole={user.role} userName={user.name} />;
      case 'notifications':
        return <NotificationPanel />;
      case 'analytics':
        return user.role === 'manager' ? <KPIDashboard /> : <DashboardOverview userRole={user.role} userName={user.name} />;
      case 'validation':
        return user.role === 'supervisor' ? <TaskList userRole={user.role} userName={user.name} /> : <DashboardOverview userRole={user.role} userName={user.name} />;
      default:
        return <DashboardOverview userRole={user.role} userName={user.name} />;
    }
  };

  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <MainLayout
        user={user}
        currentView={currentView}
        onViewChange={setCurrentView}
        onLogout={handleLogout}
      >
        {renderCurrentView()}
      </MainLayout>
    </div>
  );
}